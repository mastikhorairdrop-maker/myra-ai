package com.myra.ai.comms

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telephony.SmsManager
import com.myra.ai.core.MyraConfig

/** Calls, SMS, WhatsApp intents and contact lookup. Permissions are checked by the caller. */
class CommsController(private val ctx: Context) {

    /** First contact whose name contains [name] → (display name, number). Needs READ_CONTACTS. */
    fun findContact(name: String): Pair<String, String>? {
        val phone = ContactsContract.CommonDataKinds.Phone
        val cursor = ctx.contentResolver.query(
            phone.CONTENT_URI,
            arrayOf(phone.DISPLAY_NAME, phone.NUMBER),
            "${phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            "${phone.DISPLAY_NAME} ASC"
        ) ?: return null
        cursor.use {
            return if (it.moveToFirst()) it.getString(0) to it.getString(1) else null
        }
    }

    /** Digits only, with country code, as wa.me expects. */
    fun whatsappNumber(number: String): String {
        val cleaned = number.filter { it.isDigit() || it == '+' }
        return when {
            cleaned.startsWith("+") -> cleaned.drop(1)
            cleaned.startsWith("00") -> cleaned.drop(2)
            cleaned.length == 10 -> MyraConfig.DEFAULT_COUNTRY_CODE + cleaned
            cleaned.length == 11 && cleaned.startsWith("0") -> MyraConfig.DEFAULT_COUNTRY_CODE + cleaned.drop(1)
            else -> cleaned
        }
    }

    /** Direct call (needs CALL_PHONE). */
    fun call(number: String) {
        ctx.startActivity(
            Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number)))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    /** Silent SMS (needs SEND_SMS). */
    fun sendSms(number: String, body: String) {
        @Suppress("DEPRECATION")
        val sms = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
        else SmsManager.getDefault()
        sms.sendMultipartTextMessage(number, null, sms.divideMessage(body), null, null)
    }

    private fun whatsappPackage(): String? =
        listOf("com.whatsapp", "com.whatsapp.w4b")
            .firstOrNull { ctx.packageManager.getLaunchIntentForPackage(it) != null }

    /** Opens a chat (optionally with text pre-filled). Null if WhatsApp isn't installed. */
    fun whatsappIntent(digits: String, text: String?): Intent? {
        val pkg = whatsappPackage() ?: return null
        val url = "https://wa.me/$digits" + (text?.let { "?text=" + Uri.encode(it) } ?: "")
        return Intent(Intent.ACTION_VIEW, Uri.parse(url))
            .setPackage(pkg)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun whatsappLaunch(): Intent? =
        whatsappPackage()?.let { ctx.packageManager.getLaunchIntentForPackage(it) }
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
