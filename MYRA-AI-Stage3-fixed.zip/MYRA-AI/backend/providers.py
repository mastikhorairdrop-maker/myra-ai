"""Streaming adapters. Every provider exposes: name, available, stream(system, messages, max_tokens)."""
from typing import AsyncIterator, Protocol

import config


class Provider(Protocol):
    name: str

    @property
    def available(self) -> bool: ...

    def stream(self, system: str, messages: list[dict], max_tokens: int) -> AsyncIterator[str]: ...


class ClaudeProvider:
    name = "claude"

    def __init__(self, key: str, model: str):
        self.model = model
        self.client = None
        if key:
            from anthropic import AsyncAnthropic

            self.client = AsyncAnthropic(api_key=key, timeout=60)

    @property
    def available(self) -> bool:
        return self.client is not None

    async def stream(self, system, messages, max_tokens):
        async with self.client.messages.stream(
            model=self.model, system=system, messages=messages, max_tokens=max_tokens
        ) as s:
            async for text in s.text_stream:
                yield text


class OpenAICompatProvider:
    """Works for OpenAI and Groq (Groq exposes an OpenAI-compatible endpoint)."""

    def __init__(self, name: str, key: str, model: str, base_url: str | None = None):
        self.name = name
        self.model = model
        self.client = None
        if key:
            from openai import AsyncOpenAI

            self.client = AsyncOpenAI(api_key=key, base_url=base_url, timeout=60)

    @property
    def available(self) -> bool:
        return self.client is not None

    async def stream(self, system, messages, max_tokens):
        msgs = [{"role": "system", "content": system}] + messages
        resp = await self.client.chat.completions.create(
            model=self.model, messages=msgs, max_completion_tokens=max_tokens, stream=True
        )
        async for chunk in resp:
            if chunk.choices and chunk.choices[0].delta and chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content


class GeminiProvider:
    name = "gemini"

    def __init__(self, key: str, model: str):
        self.model = model
        self.client = None
        if key:
            from google import genai

            self.client = genai.Client(api_key=key)

    @property
    def available(self) -> bool:
        return self.client is not None

    async def stream(self, system, messages, max_tokens):
        from google.genai import types

        contents = [
            types.Content(
                role="user" if m["role"] == "user" else "model",
                parts=[types.Part(text=m["content"])],
            )
            for m in messages
        ]
        cfg = types.GenerateContentConfig(system_instruction=system, max_output_tokens=max_tokens)
        stream = await self.client.aio.models.generate_content_stream(
            model=self.model, contents=contents, config=cfg
        )
        async for chunk in stream:
            if chunk.text:
                yield chunk.text


def build_providers() -> dict[str, Provider]:
    return {
        "claude": ClaudeProvider(config.ANTHROPIC_API_KEY, config.CLAUDE_MODEL),
        "openai": OpenAICompatProvider("openai", config.OPENAI_API_KEY, config.OPENAI_MODEL),
        "groq": OpenAICompatProvider(
            "groq", config.GROQ_API_KEY, config.GROQ_MODEL, "https://api.groq.com/openai/v1"
        ),
        "gemini": GeminiProvider(config.GEMINI_API_KEY, config.GEMINI_MODEL),
    }
