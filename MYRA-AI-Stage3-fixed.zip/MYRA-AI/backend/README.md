# MYRA backend

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # set MYRA_TOKEN and at least one API key
uvicorn main:app --host 0.0.0.0 --port 8000
```

- Android emulator reaches this machine at `ws://10.0.2.2:8000/ws`. A real phone needs your LAN IP, or (better) a public host behind HTTPS/WSS (Caddy, nginx, Render, Fly...).
- Set the same token in the app's `gradle.properties` (`MYRA_TOKEN`) and `MYRA_BACKEND_URL`.
- Tests: `python tests/test_codegen.py` (no deps) and `python tests/test_ws.py` (needs fastapi + httpx).
- Not included: per-user rate limiting. Put the server behind a reverse proxy with limits before exposing it publicly.
