"""Website generation helpers: prompt, request detection, and a streaming multi-file parser.

Model output format (enforced by CODEGEN_SYSTEM):
    ===FILE: index.html===
    ...content...
    ===END===
"""
import posixpath
import re

CODEGEN_SYSTEM = """You are MYRA's build engine. Produce a complete, working static website for the request.

Output ONLY files in exactly this format, with no commentary and no markdown fences:
===FILE: index.html===
<file content>
===END===

Rules:
- index.html is required. At most 6 files. Allowed types: .html .css .js .json .svg .txt .md
- Reference local files with relative paths only (e.g. style.css, script.js).
- No build tools. External libraries only from https://cdnjs.cloudflare.com.
- Responsive, accessible, polished. Default look: dark gothic cyberpunk (obsidian #0A0A0C, neon purple #A855F7, electric red #FF0055) unless the request says otherwise.
- Never include API keys, tracking, or code that sends user data anywhere.
"""

ALLOWED_EXT = {".html", ".css", ".js", ".json", ".svg", ".txt", ".md"}
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._\-/]{0,80}$")
HEADER_RE = re.compile(r"===FILE:\s*(.+?)\s*===[ \t]*\r?\n")
END_MARK = "===END==="

_BUILD_WHAT = re.compile(
    r"(website|web ?site|web ?page|landing ?page|portfolio|html|css|javascript|web ?app|frontend)"
    r"|वेबसाइट|वेबपेज|लैंडिंग पेज|पोर्टफोलियो",
    re.IGNORECASE,
)
_BUILD_VERB = re.compile(
    r"\b(bana|banao|banado|banaao|banana|build|create|make|generate|design|likho|code)\w*"
    r"|बना|बनाओ|बनाइए|लिखो",
    re.IGNORECASE,
)


def looks_like_build_request(text: str) -> bool:
    return bool(_BUILD_WHAT.search(text) and _BUILD_VERB.search(text))


class CodegenError(Exception):
    pass


def sanitize_filename(raw: str) -> str | None:
    name = raw.strip()
    if "\\" in name or not NAME_RE.match(name) or name.startswith("/"):
        return None
    norm = posixpath.normpath(name)
    if norm.startswith("..") or "/.." in norm or norm != name:
        return None
    if posixpath.splitext(norm)[1].lower() not in ALLOWED_EXT:
        return None
    return norm


def strip_fences(text: str) -> str:
    t = text.strip("\n")
    t = re.sub(r"^```[a-zA-Z0-9]*\n", "", t)
    t = re.sub(r"\n```\s*$", "", t)
    return t.rstrip() + "\n"


class FileStreamParser:
    """Incremental parser. feed() returns events:
    ("start", name) | ("chunk", name, text) | ("done", name, size_bytes)
    """

    def __init__(self, max_files: int = 8, max_bytes: int = 400_000):
        self.max_files = max_files
        self.max_bytes = max_bytes
        self.buf = ""
        self.current: str | None = None
        self.skipping = False
        self.sizes: dict[str, int] = {}
        self.total = 0

    def _emit(self, text: str, out: list) -> None:
        if not text or self.skipping or self.current is None:
            return
        n = len(text.encode("utf-8"))
        self.sizes[self.current] += n
        self.total += n
        if self.total > self.max_bytes:
            raise CodegenError("generated output too large")
        out.append(("chunk", self.current, text))

    def feed(self, text: str) -> list:
        self.buf += text
        out: list = []
        while True:
            if self.current is None and not self.skipping:
                m = HEADER_RE.search(self.buf)
                if not m:
                    self.buf = self.buf[-80:]  # may hold a partial header
                    return out
                name = sanitize_filename(m.group(1))
                self.buf = self.buf[m.end():]
                if name is None or name in self.sizes or len(self.sizes) >= self.max_files:
                    self.skipping = True
                else:
                    self.current = name
                    self.sizes[name] = 0
                    out.append(("start", name))
                continue
            i = self.buf.find(END_MARK)
            if i == -1:
                keep = len(END_MARK) - 1
                if len(self.buf) > keep:
                    self._emit(self.buf[:-keep], out)
                    self.buf = self.buf[-keep:]
                return out
            self._emit(self.buf[:i], out)
            self.buf = self.buf[i + len(END_MARK):]
            if self.current is not None:
                out.append(("done", self.current, self.sizes[self.current]))
            self.current = None
            self.skipping = False

    def finish(self) -> list:
        """Call once the model stops. Closes a file left open by truncated output."""
        out: list = []
        if self.current is not None:
            self._emit(self.buf, out)
            out.append(("done", self.current, self.sizes[self.current]))
        self.buf, self.current, self.skipping = "", None, False
        return out
