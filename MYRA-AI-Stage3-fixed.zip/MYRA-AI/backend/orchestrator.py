"""Multi-model orchestration: try providers in order, fall back on error / empty / slow first token."""
import asyncio
import time
from typing import AsyncIterator, Awaitable, Callable


class AllProvidersFailed(Exception):
    pass


async def _close(agen) -> None:
    try:
        await agen.aclose()
    except Exception:
        pass


async def stream_chain(
    chain: list[str],
    providers: dict,
    system: str,
    messages: list[dict],
    max_tokens: int,
    first_token_timeout: float,
    log: Callable[[str], Awaitable[None]],
) -> AsyncIterator[tuple]:
    """Yields ("provider", name, first_token_ms) once, then ("token", text) repeatedly.

    Fallback only happens BEFORE the first token. A failure mid-stream propagates to the caller
    (restarting a half-spoken answer on another model would be worse than ending it).
    """
    tried = 0
    for name in chain:
        p = providers.get(name)
        if p is None or not p.available:
            continue
        tried += 1
        agen = p.stream(system, messages, max_tokens)
        t0 = time.perf_counter()
        try:
            first = await asyncio.wait_for(agen.__anext__(), timeout=first_token_timeout)
        except StopAsyncIteration:
            await log(f"{name}: empty reply, trying next")
            await _close(agen)
            continue
        except Exception as e:  # includes timeouts, auth errors, rate limits, bad model ids
            await log(f"{name}: {type(e).__name__}, trying next")
            await _close(agen)
            continue

        yield "provider", name, (time.perf_counter() - t0) * 1000
        yield "token", first
        try:
            async for chunk in agen:
                yield "token", chunk
        finally:
            await _close(agen)
        return
    raise AllProvidersFailed(f"no provider answered (tried {tried})")
