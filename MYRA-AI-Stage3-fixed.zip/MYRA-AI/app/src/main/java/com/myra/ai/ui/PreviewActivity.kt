package com.myra.ai.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.myra.ai.R
import com.myra.ai.core.MyraConfig
import com.myra.ai.core.Safe

/** Live preview of a generated website. Only loads pages from MYRA's own backend. */
class PreviewActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_URL = "url"
        fun open(ctx: Context, url: String) = Safe.exec("preview.open") {
            ctx.startActivity(Intent(ctx, PreviewActivity::class.java).putExtra(EXTRA_URL, url))
        }
    }

    private var web: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra(EXTRA_URL)
        if (url.isNullOrBlank() || !url.startsWith(MyraConfig.httpBase)) {
            finish()
            return
        }
        try {
            setContentView(R.layout.activity_preview)
            val status = findViewById<TextView>(R.id.previewStatus)
            val view = findViewById<WebView>(R.id.web)
            web = view
            findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
            findViewById<View>(R.id.btnReload).setOnClickListener { Safe.exec("preview.reload") { view.reload() } }

            view.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            }
            view.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean {
                    if (request.url.toString().startsWith(MyraConfig.httpBase)) return false
                    Safe.exec("preview.external") { startActivity(Intent(Intent.ACTION_VIEW, request.url)) }
                    return true
                }

                override fun onPageFinished(v: WebView, u: String) {
                    status.text = "Live preview"
                }

                override fun onReceivedError(v: WebView, request: WebResourceRequest, error: WebResourceError) {
                    if (request.isForMainFrame) status.text = "Load failed: ${error.description}"
                }

                // A crashed renderer must not take the app with it
                override fun onRenderProcessGone(v: WebView, detail: RenderProcessGoneDetail): Boolean {
                    Safe.exec("preview.gone") { finish() }
                    return true
                }
            }
            status.text = "Loading..."
            view.loadUrl(url)
        } catch (t: Throwable) {
            com.myra.ai.core.CrashLog.write("preview", t)
            finish()
        }
    }

    override fun onDestroy() {
        Safe.exec("preview.destroy") { web?.destroy() }
        web = null
        super.onDestroy()
    }
}
