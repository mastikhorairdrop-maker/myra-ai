package com.myra.ai.core

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/** Text-to-speech with queueing. If TTS is missing or broken, MYRA simply stays silent (text still shows). */
class Speaker(ctx: Context, private val onSpeaking: (Boolean) -> Unit) {

    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    private val seq = AtomicInteger(0)
    private val active = ConcurrentHashMap.newKeySet<String>()

    init {
        Safe.exec("tts.init") {
            tts = TextToSpeech(ctx.applicationContext) { status ->
                Safe.exec("tts.ready") {
                    val t = tts
                    if (t != null && status == TextToSpeech.SUCCESS) {
                        val r = t.setLanguage(Locale("hi", "IN"))
                        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                            t.setLanguage(Locale.getDefault())
                        }
                        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(utteranceId: String?) {}
                            override fun onDone(utteranceId: String?) = finished(utteranceId)

                            @Deprecated("Deprecated in Java")
                            override fun onError(utteranceId: String?) = finished(utteranceId)
                            override fun onError(utteranceId: String?, errorCode: Int) = finished(utteranceId)
                            override fun onStop(utteranceId: String?, interrupted: Boolean) = finished(utteranceId)
                        })
                        ready = true
                    }
                }
            }
        }
    }

    private fun finished(id: String?) {
        if (id != null && active.remove(id) && active.isEmpty()) onSpeaking(false)
    }

    fun speak(text: String) {
        val t = tts
        if (!ready || t == null) return
        val clean = text.replace(Regex("https?://\\S+"), " ").replace(Regex("[*_#`>~]"), "").trim()
        if (clean.isEmpty()) return
        Safe.exec("tts.speak") {
            val id = "u${seq.incrementAndGet()}"
            active.add(id)
            onSpeaking(true)
            if (t.speak(clean, TextToSpeech.QUEUE_ADD, null, id) != TextToSpeech.SUCCESS) finished(id)
        }
    }

    fun stop() {
        Safe.exec("tts.stop") {
            active.clear()
            tts?.stop()
            onSpeaking(false)
        }
    }

    fun shutdown() {
        Safe.exec("tts.shutdown") {
            tts?.shutdown()
            tts = null
            ready = false
        }
    }
}

/** Cuts a token stream into speakable sentences so TTS can start before the answer is complete. */
class SentenceChunker(private val emit: (String) -> Unit) {
    private val sb = StringBuilder()

    fun feed(t: String) {
        for (ch in t) {
            sb.append(ch)
            val end = ch == '.' || ch == '!' || ch == '?' || ch == '।' || ch == '\n'
            if ((end && sb.length >= 25) || (ch == ' ' && sb.length >= 160)) flush()
        }
    }

    fun flush() {
        val s = sb.toString().trim()
        sb.setLength(0)
        if (s.isNotEmpty()) emit(s)
    }
}
