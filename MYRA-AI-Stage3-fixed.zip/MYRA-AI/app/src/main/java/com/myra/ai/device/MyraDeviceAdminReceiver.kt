package com.myra.ai.device

import android.app.admin.DeviceAdminReceiver

/** Grants the force-lock policy so DevicePolicyManager.lockNow() works. */
class MyraDeviceAdminReceiver : DeviceAdminReceiver()
