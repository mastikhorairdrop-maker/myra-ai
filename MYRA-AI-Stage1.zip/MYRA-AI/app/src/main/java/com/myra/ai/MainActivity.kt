package com.myra.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.ColorRes
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.myra.ai.databinding.ActivityMainBinding
import com.myra.ai.ui.ActionAdapter
import com.myra.ai.ui.LogAdapter
import com.myra.ai.ui.OrbView
import com.myra.ai.ui.QuickAction

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val logAdapter = LogAdapter()
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var connectivity: ConnectivityManager

    private var recognizer: SpeechRecognizer? = null
    private var listening = false

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening()
            else log("SYS", "Mic permission nahi mili, Boss. Bina kaan ke kaise sunu?", R.color.electric_red)
        }

    private val netCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { ui.post { setNetwork(true) } }
        override fun onLost(network: Network) { ui.post { setNetwork(false) } }
    }

    private val actions = listOf(
        QuickAction("whatsapp", "WhatsApp", R.drawable.ic_chat, R.color.ok_green),
        QuickAction("voice", "Voice Assistant", R.drawable.ic_mic, R.color.neon_purple),
        QuickAction("screen", "Screen Automation", R.drawable.ic_screen, R.color.cyan),
        QuickAction("device", "Device Tools", R.drawable.ic_lock, R.color.electric_red),
        QuickAction("code", "Code Builder", R.drawable.ic_code, R.color.neon_purple)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        connectivity = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager

        b.logList.layoutManager = LinearLayoutManager(this)
        b.logList.adapter = logAdapter

        b.actionGrid.layoutManager = GridLayoutManager(this, 3)
        b.actionGrid.adapter = ActionAdapter(actions, ::onAction)

        b.orbView.setOnClickListener { toggleListening() }

        val active = connectivity.activeNetwork
        val caps = active?.let { connectivity.getNetworkCapabilities(it) }
        setNetwork(caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true)
        connectivity.registerDefaultNetworkCallback(netCallback)

        setState(OrbView.State.IDLE)
        bootSequence()
    }

    // ---------- Terminal ----------

    private fun log(tag: String, text: String, @ColorRes color: Int = R.color.text_primary) {
        logAdapter.add(LogAdapter.Line(tag, text, ContextCompat.getColor(this, color)))
        b.logList.scrollToPosition(logAdapter.itemCount - 1)
    }

    private fun bootSequence() {
        val lines = listOf(
            Triple("BOOT", "MYRA core initialize ho raha hai...", R.color.cyan),
            Triple("BOOT", "Voice engine: hi-IN ready", R.color.cyan),
            Triple("BOOT", "Orchestrator: offline (backend Stage 3 mein judega)", R.color.text_dim),
            Triple("MYRA", "Aa gaye Boss? Main toh kab se ready thi. Bolo, kya karna hai?", R.color.neon_purple)
        )
        lines.forEachIndexed { i, (tag, text, color) ->
            ui.postDelayed({ log(tag, text, color) }, 450L * (i + 1))
        }
    }

    // ---------- Orb / state ----------

    private fun setState(s: OrbView.State) {
        b.orbView.state = s
        b.stateText.text = when (s) {
            OrbView.State.IDLE -> "Tap the orb to speak"
            OrbView.State.LISTENING -> "Listening..."
            OrbView.State.THINKING -> "Processing..."
            OrbView.State.SPEAKING -> "MYRA speaking"
        }
        if (s != OrbView.State.LISTENING) b.orbView.setLevel(0f)
    }

    private fun setNetwork(online: Boolean) {
        val color = ContextCompat.getColor(this, if (online) R.color.ok_green else R.color.electric_red)
        b.statusDot.backgroundTintList = ColorStateList.valueOf(color)
        b.statusText.text = if (online) "Online" else "Offline"
    }

    // ---------- Quick actions ----------

    private fun onAction(a: QuickAction) {
        when (a.id) {
            "voice" -> toggleListening()
            "code" -> log("MYRA", "Code Builder Stage 3 mein aayega, backend ke saath. Sabar, Boss.", R.color.neon_purple)
            else -> log("MYRA", "${a.label} module Stage 2 mein aa raha hai. Abhi sirf entry gate khula hai.", R.color.neon_purple)
        }
    }

    // ---------- Voice ----------

    private fun toggleListening() {
        if (listening) stopListening() else requestMicAndListen()
    }

    private fun requestMicAndListen() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED
        ) startListening() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            log("SYS", "Speech recognition is device par available nahi hai.", R.color.electric_red)
            return
        }
        val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(listener)
            recognizer = it
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        listening = true
        setState(OrbView.State.LISTENING)
        r.startListening(intent)
    }

    private fun stopListening() {
        listening = false
        recognizer?.stopListening()
        setState(OrbView.State.IDLE)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onRmsChanged(rmsdB: Float) {
            // rmsdB is roughly -2..10 → normalise to 0..1 for the orb
            b.orbView.setLevel((rmsdB + 2f) / 12f)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) b.stateText.text = t
        }

        override fun onResults(results: Bundle?) {
            listening = false
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text.isNullOrBlank()) {
                setState(OrbView.State.IDLE)
                return
            }
            log("YOU", text, R.color.cyan)
            respond(text)
        }

        override fun onError(error: Int) {
            listening = false
            setState(OrbView.State.IDLE)
            val msg = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    "Kuch suna hi nahi, Boss. Dobara bolo."
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                    "Network ka scene kharab hai."
                else -> "Voice error (code $error)."
            }
            log("SYS", msg, R.color.electric_red)
        }
    }

    /** Placeholder until the Stage 3 backend is wired in. */
    private fun respond(userText: String) {
        setState(OrbView.State.THINKING)
        ui.postDelayed({
            setState(OrbView.State.SPEAKING)
            log("MYRA", "\"$userText\" — note kar liya, Boss. Dimaag (backend) abhi connect nahi hua.", R.color.neon_purple)
        }, 900)
        ui.postDelayed({ setState(OrbView.State.IDLE) }, 2800)
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        runCatching { connectivity.unregisterNetworkCallback(netCallback) }
        super.onDestroy()
    }
}
