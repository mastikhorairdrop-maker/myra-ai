package com.myra.ai.core

/** Tweak MYRA's behaviour here. */
object MyraConfig {
    /** hi-IN returns Devanagari for Hindi words; the router understands both scripts. Try "en-IN" for Roman-only output. */
    const val SPEECH_LANG = "hi-IN"

    /** Prefix for 10-digit local numbers when opening WhatsApp chats. */
    const val DEFAULT_COUNTRY_CODE = "91"

    /** true = MYRA taps WhatsApp's Send button herself. false = she only opens the chat with text filled in. */
    const val WHATSAPP_AUTO_SEND = true
}
